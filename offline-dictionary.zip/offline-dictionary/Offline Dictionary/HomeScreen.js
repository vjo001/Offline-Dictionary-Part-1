import React, { Component } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity } from 'react native';
import { Header } from 'react-native-elements';
import dictionary from '../database';
export default class HomeScreen extends Component{
  constructor() {
    super();
    this.state = {
      text: '',
      isSearchPressed: false,
      isLoading: false,
      word  : "Loading...",
      lexicalCategory :'',
      definition :""
    };
  }

  getWord=(text)=>{
    var text = text.toLowerCase()
    try{
      var word = dictionary[text]["word"]
      var lexicalCategory = dictionary[text]["lexicalCategoty"]
      var definition = dictionary[text]["definition"]
      this.setState({
        "word" : word,
        "lexicalCategory" : lexicalCategory,
        "definition" : definition
      })
    }
    catch(err){
      alert("Sorry, this word isn't available rigt now.")
      this.setState({
        'text':'',
        'isSearchPressed':false
      })
    }
  }

  render(){
    return(
      <View style={{flex:1, borderWidth:2}}>
        <Header
          backgroundColor={'purple'}
          centerComponent={{
            text: 'Pocket Dictionary',
            style: { color: 'fc0093', fontSize:20 }
          }}
        />
        <View style={styles.inputBoxContainer}>
          <TextInput
          style={styles.inputBox}
          onChangeText={text => {
            this.setState({
              text: test,
              isSearchPressed: false,
              word  : "Loading...",
              lexicalCategory :'',
              examples : [],
              definition :""
            });
          }}
          value={this.state.text}
        />

        <TouchableOpacity
          style={styles.searchButton}
          onPress={() => {
            this.setState({ isSearchPressed: true });
            this.getWord(this.state.text)
          }}>
          <Text style={styles.searchText}>Search</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.outputContainer}>
        <Text stule={{fontSize:20}}>
          {
            this.state.isSearchPressed && this.state.word === "Loading...
            ? this.state.word
            : ""
          }
        </Text>
          {
            this.state.word !== "Loading..." ?
            (
              <Viewstyle={{justifyContent:'center', marginLeft:10 }}>
                
            )
          }
    )
  }
}